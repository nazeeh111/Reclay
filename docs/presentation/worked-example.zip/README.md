# Reclay recorded synthetic edit

Current parent9d4b6b008c6474afd4bc91a1ab19de36c15b9106. Synthetic Pillow TIFF, not a private file.

In this fresh directory run ordinary Python3.10+: 

    python3 -I editor.py rebuild working.tif replacement.bin rebuilt.tif --start 146 --end 194

Reclay is not needed. rebuilt.tif should exactly match edited.tif (see MANIFEST.json). Existing outputs are refused. The model covers one supplied marked span and a fixed document envelope; it is not a TIFF specification.
journey.json preserves the original source-checkout CLI commands, whose absolute paths describe that original run and are not ZIP members. The command above uses only this bundle. decoded.json records independent Pillow image decoding; Pillow is optional for that independent check.

All listed MANIFEST.json paths are included. Original code and synthetic data MIT; see LICENSE. No unknown executable is bundled. editor.py is the inspectable exported standard-library source.
